package com.example.campground;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelperr extends SQLiteOpenHelper {
    public static final String dbname="login.db";
    private String Password;

    public DBHelperr( Context context) {
        super(context,"login.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase mydb) {
        mydb.execSQL("create table users(username TEXT Primary key,Password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase mydb, int i, int i1) {
        mydb.execSQL("drop table if exists users");
    }
    public boolean insertdata(String username,String Password){
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("username",username);
        cv.put("password",Password);
        long result = mydb.insert("users",null,cv);
        if(result==-1)return false;
        else return true;
    }
    public boolean checkusername(String username){
        SQLiteDatabase mydb = this.getWritableDatabase();
        Cursor cursor=mydb.rawQuery("Select * from users where username = ?",new String[]{username});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public boolean checkusernamepassword(String username,String Password){
        SQLiteDatabase mydb = this.getWritableDatabase();
        Cursor cursor=mydb.rawQuery("Select * from users where username = ? and password=?",new String[]{username,Password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
}

