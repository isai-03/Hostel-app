package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class teachevent extends AppCompatActivity {
    Button event,mess,complaint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachevent);
        event = findViewById(R.id.evntbtn);
        mess = findViewById(R.id.messbtn);
        complaint = findViewById(R.id.cmplntbtn);
        event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(teachevent.this,upeveteach.class);
                startActivity(intent);
            }
        });
        mess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(teachevent.this,teachmess.class);
                startActivity(intent);
            }
        });
        complaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(teachevent.this,teachcomplaint.class);
                startActivity(intent);
            }
        });
    }

}