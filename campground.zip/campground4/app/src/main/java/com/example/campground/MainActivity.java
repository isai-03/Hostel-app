package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText username,password;
    Button btnlogin;
    String correctusername = "REC";
    String correctpassword = "admin";
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        btnlogin = findViewById(R.id.button);

        btnlogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                if(TextUtils.isEmpty(username.getText().toString()) || TextUtils.isEmpty(password.getText().toString())){
                    Toast.makeText(MainActivity.this,"Empty Data",Toast.LENGTH_LONG).show();
                }else if(username.getText().toString().equals(correctusername)) {
                    if(password.getText().toString().equals(correctpassword)){
                        Toast.makeText(MainActivity.this,"Successfully logged in ",Toast.LENGTH_LONG).show();



                        Intent intent= new Intent(MainActivity.this,Homepage.class);
                        startActivity(intent);


                    }else{
                        Toast.makeText(MainActivity.this,"Invalid Credentials",Toast.LENGTH_LONG).show();

                    }
                }else{
                    Toast.makeText(MainActivity.this,"Invalid username/password",Toast.LENGTH_LONG).show();

                }
            }
        });
    }

}