package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class stuhome extends AppCompatActivity {
 Button rooms,event;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stuhome);
        rooms = findViewById(R.id.roombtn);
        event=findViewById(R.id.eventbtn);
        event.setOnClickListener(new View.OnClickListener() {
            @Override

                public void onClick(View view) {
                    Intent intent = new Intent(stuhome.this,eventstu.class);
                    startActivity(intent);
            }
        });
        rooms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(stuhome.this,rooms.class);
                startActivity(intent);
            }
        });
    }
}