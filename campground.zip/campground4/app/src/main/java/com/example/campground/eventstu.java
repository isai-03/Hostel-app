package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class eventstu extends AppCompatActivity {
   Button event,mess,complaint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventstu);
        event = findViewById(R.id.evntbtn);
        mess = findViewById(R.id.messbtn);
        complaint = findViewById(R.id.cmplntbtn);
        event.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(eventstu.this,upevestu.class);
                startActivity(intent);
            }
        });
        mess.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(eventstu.this,stumess.class);
                startActivity(intent);
            }
        });
        complaint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(eventstu.this,stucomplaint.class);
                startActivity(intent);
            }
        });
    }

}