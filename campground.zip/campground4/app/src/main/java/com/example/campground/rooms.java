package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class rooms extends AppCompatActivity {
   Button twin,triple,ac;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rooms);
        twin=findViewById(R.id.twinroom);
        triple=findViewById(R.id.tripleroom);
        ac=findViewById(R.id.acroom);
        twin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(rooms.this,twinroom.class);
                startActivity(intent);
            }
        });
        triple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(rooms.this,triple.class);
                startActivity(intent);
            }
        });
        ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(rooms.this,acstu.class);
                startActivity(intent);
            }
        });
    }
}