package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class teachhome extends AppCompatActivity {
 Button book,eve;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachhome);
        book = findViewById(R.id.roombtn);
        eve=findViewById(R.id.eventbtn);
        eve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(teachhome.this,teachevent.class);
                startActivity(intent);
            }
        });
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(teachhome.this,teachroom.class);
                startActivity(intent);
            }
        });
    }
}