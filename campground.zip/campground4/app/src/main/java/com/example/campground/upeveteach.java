package com.example.campground;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class upeveteach extends AppCompatActivity {

        Button regform,inst,college;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_upevestu);
            inst = findViewById(R.id.instagram);
            inst.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    gotoUrl("https://www.instagram.com/p/CdpS3pTLUVM/?igshid=YmMyMTA2M2Y=");
                }
            });
            regform = findViewById(R.id.regform);
            regform.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    gotoUrl("https://docs.google.com/forms/d/e/1FAIpQLSetbh2-MrBop_KyZrgd3Sgh79fj3Rlv61mUnkGrqMOyT7gdIg/viewform");
                }
            });
            college=findViewById(R.id.college);
            college.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    gotoUrl("https://www.rajalakshmi.org/");
                }
            });
        }

        private void gotoUrl(String s) {
            Uri uri = Uri.parse(s);
            startActivity(new Intent(Intent.ACTION_VIEW,uri));
        }
    }